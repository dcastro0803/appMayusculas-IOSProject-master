//
//  ViewControllerRespuestas2.swift
//  appMayusculas
//
//  Created by user164056 on 4/20/20.
//  Copyright © 2020 Daniel. All rights reserved.
//

import UIKit

class ViewControllerRespuestas2: UIViewController {

    @IBOutlet weak var lResp1: UILabel!
    @IBOutlet weak var lResp2: UILabel!
    @IBOutlet weak var lResp3: UILabel!
    
    
    @IBOutlet weak var imgImagen1: UIImageView!
    @IBOutlet weak var imgImagen2: UIImageView!
    @IBOutlet weak var imgImagen3: UIImageView!
    
    @IBOutlet weak var lTip1: UILabel!
    @IBOutlet weak var lTip2: UILabel!
    @IBOutlet weak var lTip3: UILabel!
    
    
    @IBOutlet weak var btnSiguiente: UIButton!
    
    var Respuesta1 : String!
    var Respuesta2 : String!
    var Respuesta3 : String!
    var arrBool: [Bool]!
    var Tip1 : String!
    var Tip2 : String!
    var Tip3 : String!
    var arrImag : [UIImageView]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Resultado Ejercicio 2"
        btnSiguiente.applyDesignButtons()
        lResp1.text = Respuesta1
        lResp2.text = Respuesta2
        lResp3.text = Respuesta3
        
        arrImag = [imgImagen1, imgImagen2, imgImagen3]
        let arrTip = [Tip1, Tip2, Tip3]
        let arrTipSt = [lTip1, lTip2, lTip3]
        
        for i in 0..<3{
            if arrBool[i]{
                arrImag[i].image = UIImage.init(named: "good")
            }
            else if !arrBool[i]{
                arrImag[i].image = UIImage.init(named: "bad")
                arrTipSt[i]?.text = arrTip[i]
            }
        }
        // Do any additional setup after loading the view.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    

}
