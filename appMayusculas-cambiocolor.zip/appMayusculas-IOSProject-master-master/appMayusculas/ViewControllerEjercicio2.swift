//
//  ViewControllerEjercicio2.swift
//  appMayusculas
//
//  Created by user164056 on 4/20/20.
//  Copyright © 2020 Daniel. All rights reserved.
//

import UIKit

class ViewControllerEjercicio2: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var lPregunta1: UILabel!
    @IBOutlet weak var lPregunta2: UILabel!
    @IBOutlet weak var lPregunta3: UILabel!
    
    @IBOutlet weak var tfRespuesta1: UITextField!
    @IBOutlet weak var tfRespuesta2: UITextField!
    @IBOutlet weak var tfRespuesta3: UITextField!
    
    @IBOutlet weak var lAyuda: UILabel!
    @IBOutlet weak var lAyuda2: UILabel!
    @IBOutlet weak var lAyuda3: UILabel!
    
    
    @IBOutlet weak var btnRevisar: UIButton!
    
    var arrReglasMayusculas : NSArray!
    var arrReglasMinusculas : NSArray!
    var arrSoluciones = [String]()
    var arrOpcionCorrecta = [String]()
    var arrRespuestas = [String]()
    var arrHelp = [String]()
    var arrTip = [String]()
    var Corr=[Bool]()
    var arrUsado = [Int]()
    @IBOutlet weak var scrollview: UIScrollView!
    

    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
        
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.setHidesBackButton(true, animated: true)
        self.tfRespuesta1.delegate = self
        self.tfRespuesta2.delegate = self
        self.tfRespuesta3.delegate = self
        btnRevisar.applyDesignButtons()
        self.title = "Ejercicio 2"
        
        //self.tfRespuesta1.delegate = self
        
        let arrAy = [lAyuda, lAyuda2, lAyuda3]
        
        let arrTf = [tfRespuesta1, tfRespuesta2, tfRespuesta3]
        var pathReglas = Bundle.main.path(forResource: "ReglasMayusculas", ofType: "plist")
        arrReglasMayusculas = NSArray(contentsOfFile: pathReglas!)
        
        pathReglas = Bundle.main.path(forResource: "ReglasMinusculas", ofType: "plist")
        arrReglasMinusculas = NSArray(contentsOfFile: pathReglas!)        // Do any additional setup after loading the view.
        let arrayLabels = [lPregunta1, lPregunta2, lPregunta3]
        var arrayAnswers = [-1,-1,-1,-1,-1]

        let auxSet: [Int] = []
        let counterElementsRendered : Set = Set(auxSet)
        
        // Start the looping for the Mayusc
        var randomNumber = Int.random(in: 0..<arrReglasMayusculas.count)
        
        // We start with 2 Mayusculas
        for n in 0..<2 {
            randomNumber = Int.random(in: 0..<arrReglasMayusculas.count)
            print(randomNumber)
            
            if(arrUsado.count == 0){
                arrUsado.append(randomNumber)
            }else if(arrUsado.count > 0){
                        while(randomNumber == arrUsado[n-1]){
                    randomNumber = Int.random(in: 0..<arrReglasMayusculas.count)
                    }
                arrUsado.append(randomNumber)
            }
            var dic = arrReglasMayusculas[randomNumber] as! NSDictionary
            let tip = dic["tip"] as! String
            var arrEjercicios = dic["ejerciciosFacil"] as! NSArray
            
            arrTip.append(tip)
            
            // Select a random number for the size
            var randomNumber = Int.random(in: 0..<arrEjercicios.count)
            
            var arrEjerciciosItem = arrEjercicios[randomNumber] as! NSArray
            
            
            
            //Here we select the dictionary: This 0 doesn't change anytime
            randomNumber = Int.random(in: 0..<arrEjerciciosItem.count)
            var dicItem = arrEjerciciosItem[randomNumber] as! NSDictionary
            
            
            let Resp = dicItem["respuesta"] as! String
            let help = dicItem["help"] as! String
            
        
            arrSoluciones.append(Resp)
            arrHelp.append(help)
            arrOpcionCorrecta.append(dicItem["opcionCorrecta"] as! String)
            
            arrayLabels[n]?.text = dicItem["pregunta"] as? String
            arrAy[n]?.text = dicItem["help"] as? String
        }
        
        // We apply the same principle as the Mayusculas exercises
        
        let dic2 = arrReglasMinusculas[0] as! NSDictionary
        let tip2 = dic2["tip"] as! String
        var arrEjercicios2 = dic2["ejerciciosFacil"] as! NSArray
        
        arrTip.append(tip2)
        
        var randomNumber2 = Int.random(in: 0..<arrEjercicios2.count)
        var arrEjerciciosItem2 = arrEjercicios2[randomNumber2] as! NSArray
        
        randomNumber2 = Int.random(in: 0..<arrEjerciciosItem2.count)
        var dicItem2 = arrEjerciciosItem2[randomNumber2] as! NSDictionary
        
        let Resp2 = dicItem2["respuesta"] as! String
        let help2 = dicItem2["help"] as! String
        
        arrHelp.append(help2)
        arrSoluciones.append(Resp2)
        arrOpcionCorrecta.append(dicItem2["opcionCorrecta"] as! String)
        
        arrayLabels[2]?.text = dicItem2["pregunta"] as? String
        arrAy[2]?.text = dicItem2["help"] as? String
        // In a function create an alert if the segmented control doesn't have an all answer
        // Check which option is correct
    }
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool{
        
        var Resp : Bool
        
        if(tfRespuesta1.text == "" || tfRespuesta2.text == "" ||
            tfRespuesta3.text == ""){
            
            let alertController = UIAlertController(title: "Cuidado", message:
                                  "Debes completar todos los campos del ejercicio", preferredStyle: .alert)
                              alertController.addAction(UIAlertAction(title: "OK", style: .default))
                              self.present(alertController, animated: true, completion: nil)
            return false
        }
        else{
            if(arrOpcionCorrecta[0] == tfRespuesta1.text){
                Resp = true
                Corr.append(Resp)
            }
            else if(arrOpcionCorrecta[0] != tfRespuesta1.text){
                Resp = false
                Corr.append(Resp)
            }
            
            if(arrOpcionCorrecta[1] == tfRespuesta2.text){
                Resp = true
                Corr.append(Resp)
                
            }
            else if(arrOpcionCorrecta[1] != tfRespuesta2.text){
                Resp = false
                Corr.append(Resp)
            }
            
            if(arrOpcionCorrecta[2] == tfRespuesta3.text){
                Resp = true
                Corr.append(Resp)            }
            else if(arrOpcionCorrecta[2] != tfRespuesta3.text){
                Resp = false
                Corr.append(Resp)
                
            }
            
        }
        
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let Resp = segue.destination as!ViewControllerRespuestas2
        
        Resp.Respuesta1 = arrSoluciones[0]
        Resp.Respuesta2 = arrSoluciones[1]
        Resp.Respuesta3 = arrSoluciones[2]
        
        Resp.Tip1 = arrTip[0]
        Resp.Tip2 = arrTip[1]
        Resp.Tip3 = arrTip[2]
        
        Resp.arrBool = Corr
        
    }
    
    @IBAction func quitaTeclado(){
        view.endEditing(true)
    }
}
