//
//  ViewControllerResultados4.swift
//  appMayusculas
//
//  Created by user164056 on 4/21/20.
//  Copyright © 2020 Daniel. All rights reserved.
//

import UIKit

class ViewControllerResultados4: UIViewController {

    @IBOutlet weak var lResp1: UILabel!
    @IBOutlet weak var lResp2: UILabel!
    @IBOutlet weak var lResp3: UILabel!
    @IBOutlet weak var imgBienMal1: UIImageView!
    @IBOutlet weak var imgBienMal2: UIImageView!
    @IBOutlet weak var imgBienMal3: UIImageView!
    
    
    @IBOutlet weak var btnSiguiente: UIButton!
    
    var Respuesta1 : String!
    var Respuesta2 : String!
    var Respuesta3 : String!
    
    var arrBool : [Bool]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btnSiguiente.applyDesignButtons()
        
        lResp1.text = Respuesta1
        lResp2.text = Respuesta2
        lResp3.text = Respuesta3
        
        let arrImg = [imgBienMal1, imgBienMal2, imgBienMal3]
        
        for i in 0..<3{
            if arrBool[i]{
                arrImg[i]?.image = UIImage.init(named: "good")
            }
            else if !arrBool[i]{
                arrImg[i]?.image = UIImage.init(named: "bad")
            }
        }

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
