//
//  ViewControllerResultados4.swift
//  appMayusculas
//
//  Created by user164056 on 4/21/20.
//  Copyright © 2020 Daniel. All rights reserved.
//

import UIKit

class ViewControllerResultados4: UIViewController {

    @IBOutlet weak var lResp1: UILabel!
    @IBOutlet weak var lResp2: UILabel!
    @IBOutlet weak var lResp3: UILabel!
    
    
    @IBOutlet weak var imgBienMal1: UIImageView!
    @IBOutlet weak var imgBienMal2: UIImageView!
    @IBOutlet weak var imgBienMal3: UIImageView!
    
    @IBOutlet weak var lTip1: UILabel!
    @IBOutlet weak var lTip2: UILabel!
    @IBOutlet weak var lTip3: UILabel!
    
    
    
    @IBOutlet weak var btnSiguiente: UIButton!
    
    var Respuesta1 : String!
    var Respuesta2 : String!
    var Respuesta3 : String!
    var Tip1 : String!
    var Tip2 : String!
    var Tip3 : String!
    
    var arrBool : [Bool]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btnSiguiente.applyDesignButtons()
        self.title = "Resultado Ejercicio 4"
        self.navigationItem.setHidesBackButton(true, animated: true)
        
        lResp1.text = Respuesta1
        lResp2.text = Respuesta2
        lResp3.text = Respuesta3
        
        let arrImg = [imgBienMal1, imgBienMal2, imgBienMal3]
        let arrlaTip = [lTip1, lTip2, lTip3]
        let arrTip = [Tip1, Tip2, Tip3]
        
        let defaults = UserDefaults.standard
        var good = defaults.integer(forKey: "good")
        var bad = defaults.integer(forKey: "bad")
        
        for i in 0..<3{
            if arrBool[i]{
                arrImg[i]?.image = UIImage.init(named: "good")
                good = good + 1
            }
            else if !arrBool[i]{
                arrImg[i]?.image = UIImage.init(named: "bad")
                arrlaTip[i]?.text = arrTip[i]
                bad = bad + 1
            }
        }
        
        // Poner e un popup
        var resultado = String(good) + " de " + String(good+bad)
        resultado = resultado  + ", puedes seguir jugando pulsando Terminar para otra ronda"
        let alertController = UIAlertController(title: "Tu Resultado es ", message:
            resultado, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: .default))
        self.present(alertController, animated: true, completion: nil)

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
